-- ============================================================================
-- FINAL MISSING COLUMNS FIX
-- ============================================================================
-- After forensic reconstruction, discovered bookings.payment_date still missing
-- This column is REQUIRED by app code (Bookings.tsx lines 540, 759)
-- ============================================================================

BEGIN;

-- Add bookings.payment_date (critical for payment tracking)
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS payment_date TIMESTAMPTZ;

-- Create index for payment date queries
CREATE INDEX IF NOT EXISTS idx_bookings_payment_date ON bookings(payment_date);

-- Add comment
COMMENT ON COLUMN bookings.payment_date IS 'Date when payment was received (used for advance and full payment tracking)';

-- Verify column exists
DO $$
DECLARE
  v_column_exists BOOLEAN;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'public' 
      AND table_name = 'bookings' 
      AND column_name = 'payment_date'
  ) INTO v_column_exists;
  
  IF v_column_exists THEN
    RAISE NOTICE '✓ bookings.payment_date exists';
  ELSE
    RAISE EXCEPTION '✗ CRITICAL: bookings.payment_date missing';
  END IF;
END $$;

COMMIT;
