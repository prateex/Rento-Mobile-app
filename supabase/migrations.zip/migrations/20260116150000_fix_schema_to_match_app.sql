-- ============================================================================
-- FINAL COMPREHENSIVE SCHEMA ALIGNMENT
-- ============================================================================
-- This migration fixes ALL remaining schema mismatches between the app code
-- and the Supabase database.
--
-- ERRORS FIXED:
-- - "Could not find the 'category' column of vehicles"
-- - "Could not find the 'notes' column of bookings"
-- - All other missing columns referenced in app code
--
-- APPROACH: Add ONLY missing columns, never drop or rename
-- ============================================================================

BEGIN;

-- ============================================================================
-- VEHICLES TABLE - FINAL ALIGNMENT
-- ============================================================================

ALTER TABLE IF EXISTS public.vehicles ADD COLUMN IF NOT EXISTS name TEXT;
ALTER TABLE IF EXISTS public.vehicles ADD COLUMN IF NOT EXISTS cc TEXT;
ALTER TABLE IF EXISTS public.vehicles ADD COLUMN IF NOT EXISTS segment TEXT;
ALTER TABLE IF EXISTS public.vehicles ADD COLUMN IF NOT EXISTS gear_type TEXT;
ALTER TABLE IF EXISTS public.vehicles ADD COLUMN IF NOT EXISTS category TEXT;
ALTER TABLE IF EXISTS public.vehicles ADD COLUMN IF NOT EXISTS vehicle_type vehicle_type;
ALTER TABLE IF EXISTS public.vehicles ADD COLUMN IF NOT EXISTS price_per_day DECIMAL(10, 2);
ALTER TABLE IF EXISTS public.vehicles ADD COLUMN IF NOT EXISTS km_driven DECIMAL(10, 2);
ALTER TABLE IF EXISTS public.vehicles ADD COLUMN IF NOT EXISTS model_year INTEGER;
ALTER TABLE IF EXISTS public.vehicles ADD COLUMN IF NOT EXISTS image TEXT;
ALTER TABLE IF EXISTS public.vehicles ADD COLUMN IF NOT EXISTS photos TEXT[] DEFAULT '{}';

-- ============================================================================
-- CUSTOMERS TABLE - FINAL ALIGNMENT
-- ============================================================================

ALTER TABLE IF EXISTS public.customers ADD COLUMN IF NOT EXISTS customer_number TEXT;
ALTER TABLE IF EXISTS public.customers ADD COLUMN IF NOT EXISTS full_name TEXT;
ALTER TABLE IF EXISTS public.customers ADD COLUMN IF NOT EXISTS id_type id_type;
ALTER TABLE IF EXISTS public.customers ADD COLUMN IF NOT EXISTS id_photos JSONB;
ALTER TABLE IF EXISTS public.customers ADD COLUMN IF NOT EXISTS notes TEXT;

-- ============================================================================
-- BOOKINGS TABLE - CRITICAL MISSING COLUMNS
-- ============================================================================

-- Timestamp columns for tracking state transitions
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS notes TEXT;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS booking_number TEXT;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS vehicle_ids UUID[] DEFAULT '{}';
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS start_datetime TIMESTAMPTZ;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS end_datetime TIMESTAMPTZ;

-- Financial fields
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS advance_amount DECIMAL(10, 2);
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS balance_amount DECIMAL(10, 2);

-- Invoice fields
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS invoice_number TEXT;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS invoice_generated_at TIMESTAMPTZ;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS invoice_generated_by UUID;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS refund_amount DECIMAL(10, 2);

-- Invoice state tracking
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS finalized BOOLEAN DEFAULT false;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS invoice_pending BOOLEAN DEFAULT false;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS invoice_locked BOOLEAN DEFAULT false;

-- Booking state tracking
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS taken_at TIMESTAMPTZ;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS taken_by UUID;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS returned_at TIMESTAMPTZ;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS returned_by UUID;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS paid_at TIMESTAMPTZ;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS paid_by UUID;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMPTZ;

-- Payment fields
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS payment_choice payment_choice;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS payment_type payment_mode;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS utr_number TEXT;

-- Damage tracking
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS damages_during_rental JSONB;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS deposit_deduction DECIMAL(10, 2) DEFAULT 0;
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS damage_notes TEXT;

-- Event history
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS history JSONB DEFAULT '[]'::jsonb;

-- WhatsApp communication tracking
ALTER TABLE IF EXISTS public.bookings ADD COLUMN IF NOT EXISTS whatsapp_sent JSONB;

-- ============================================================================
-- PAYMENTS TABLE - FINAL ALIGNMENT
-- ============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON c.relnamespace = n.oid WHERE c.relname = 'payments' AND n.nspname = 'public') THEN
    ALTER TABLE public.payments ADD COLUMN IF NOT EXISTS shop_id UUID REFERENCES rental_shops(id) ON DELETE CASCADE;
    ALTER TABLE public.payments ADD COLUMN IF NOT EXISTS booking_id UUID REFERENCES bookings(id) ON DELETE CASCADE;
    ALTER TABLE public.payments ADD COLUMN IF NOT EXISTS amount DECIMAL(10, 2);
    ALTER TABLE public.payments ADD COLUMN IF NOT EXISTS payment_mode payment_mode;
    ALTER TABLE public.payments ADD COLUMN IF NOT EXISTS utr_number TEXT;
    ALTER TABLE public.payments ADD COLUMN IF NOT EXISTS paid_by UUID REFERENCES users(id) ON DELETE SET NULL;
    ALTER TABLE public.payments ADD COLUMN IF NOT EXISTS paid_at TIMESTAMPTZ DEFAULT now();
    ALTER TABLE public.payments ADD COLUMN IF NOT EXISTS notes TEXT;
    ALTER TABLE public.payments ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT now();
    ALTER TABLE public.payments ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
  END IF;
END $$;

-- ============================================================================
-- CUSTOMER_ID_PHOTOS TABLE - FINAL ALIGNMENT
-- ============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON c.relnamespace = n.oid WHERE c.relname = 'customer_id_photos' AND n.nspname = 'public') THEN
    ALTER TABLE public.customer_id_photos ADD COLUMN IF NOT EXISTS side TEXT;
    ALTER TABLE public.customer_id_photos ADD COLUMN IF NOT EXISTS file_path TEXT;
    ALTER TABLE public.customer_id_photos ADD COLUMN IF NOT EXISTS damage_repaired_at TIMESTAMPTZ;
  END IF;
END $$;

-- ============================================================================
-- VEHICLE_DAMAGE_PHOTOS TABLE - FINAL ALIGNMENT
-- ============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON c.relnamespace = n.oid WHERE c.relname = 'vehicle_damage_photos' AND n.nspname = 'public') THEN
    ALTER TABLE public.vehicle_damage_photos ADD COLUMN IF NOT EXISTS damage_repaired_at TIMESTAMPTZ;
  END IF;
END $$;

-- ============================================================================
-- DAMAGES TABLE - FINAL ALIGNMENT
-- ============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON c.relnamespace = n.oid WHERE c.relname = 'damages' AND n.nspname = 'public') THEN
    ALTER TABLE public.damages ADD COLUMN IF NOT EXISTS shop_id UUID REFERENCES rental_shops(id) ON DELETE CASCADE;
    ALTER TABLE public.damages ADD COLUMN IF NOT EXISTS vehicle_id UUID REFERENCES vehicles(id) ON DELETE CASCADE;
    ALTER TABLE public.damages ADD COLUMN IF NOT EXISTS booking_id UUID REFERENCES bookings(id) ON DELETE SET NULL;
    ALTER TABLE public.damages ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES users(id) ON DELETE SET NULL;
    ALTER TABLE public.damages ADD COLUMN IF NOT EXISTS type damage_type NOT NULL DEFAULT 'Other';
    ALTER TABLE public.damages ADD COLUMN IF NOT EXISTS severity damage_severity NOT NULL DEFAULT 'Minor';
    ALTER TABLE public.damages ADD COLUMN IF NOT EXISTS description TEXT;
    ALTER TABLE public.damages ADD COLUMN IF NOT EXISTS photo_urls TEXT[] DEFAULT '{}';
    ALTER TABLE public.damages ADD COLUMN IF NOT EXISTS reported_by UUID REFERENCES users(id) ON DELETE SET NULL;
    ALTER TABLE public.damages ADD COLUMN IF NOT EXISTS reported_at TIMESTAMPTZ DEFAULT now();
    ALTER TABLE public.damages ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT now();
    ALTER TABLE public.damages ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
  END IF;
END $$;

-- ============================================================================
-- DOCUMENTS TABLE - FINAL ALIGNMENT
-- ============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON c.relnamespace = n.oid WHERE c.relname = 'documents' AND n.nspname = 'public') THEN
    ALTER TABLE public.documents ADD COLUMN IF NOT EXISTS shop_id UUID REFERENCES rental_shops(id) ON DELETE CASCADE;
    ALTER TABLE public.documents ADD COLUMN IF NOT EXISTS entity_type TEXT;
    ALTER TABLE public.documents ADD COLUMN IF NOT EXISTS entity_id UUID;
    ALTER TABLE public.documents ADD COLUMN IF NOT EXISTS document_type TEXT;
    ALTER TABLE public.documents ADD COLUMN IF NOT EXISTS url TEXT;
    ALTER TABLE public.documents ADD COLUMN IF NOT EXISTS uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL;
    ALTER TABLE public.documents ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT now();
    ALTER TABLE public.documents ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
  END IF;
END $$;

-- ============================================================================
-- INVOICE_SEQUENCES TABLE - FINAL ALIGNMENT
-- ============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON c.relnamespace = n.oid WHERE c.relname = 'invoice_sequences' AND n.nspname = 'public') THEN
    ALTER TABLE public.invoice_sequences ADD COLUMN IF NOT EXISTS shop_id UUID REFERENCES rental_shops(id) ON DELETE CASCADE;
    ALTER TABLE public.invoice_sequences ADD COLUMN IF NOT EXISTS fiscal_year TEXT;
    ALTER TABLE public.invoice_sequences ADD COLUMN IF NOT EXISTS sequence_number INTEGER DEFAULT 1;
    ALTER TABLE public.invoice_sequences ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT now();
    ALTER TABLE public.invoice_sequences ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
  END IF;
END $$;

-- ============================================================================
-- CUSTOMER_SEQUENCES TABLE - FINAL ALIGNMENT
-- ============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON c.relnamespace = n.oid WHERE c.relname = 'customer_sequences' AND n.nspname = 'public') THEN
    ALTER TABLE public.customer_sequences ADD COLUMN IF NOT EXISTS shop_id UUID REFERENCES rental_shops(id) ON DELETE CASCADE;
    ALTER TABLE public.customer_sequences ADD COLUMN IF NOT EXISTS sequence_number INTEGER DEFAULT 1;
    ALTER TABLE public.customer_sequences ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT now();
    ALTER TABLE public.customer_sequences ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();
  END IF;
END $$;

-- ============================================================================
-- SYNCHRONIZATION TRIGGERS (For column name aliasing)
-- ============================================================================

CREATE OR REPLACE FUNCTION sync_vehicle_columns()
RETURNS TRIGGER AS $$
BEGIN
  -- Sync type ↔ vehicle_type
  IF NEW.type IS DISTINCT FROM OLD.type THEN
    NEW.vehicle_type := NEW.type;
  ELSIF NEW.vehicle_type IS DISTINCT FROM OLD.vehicle_type THEN
    NEW.type := NEW.vehicle_type;
  END IF;

  -- Sync daily_rate ↔ price_per_day
  IF NEW.daily_rate IS DISTINCT FROM OLD.daily_rate THEN
    NEW.price_per_day := NEW.daily_rate;
  ELSIF NEW.price_per_day IS DISTINCT FROM OLD.price_per_day THEN
    NEW.daily_rate := NEW.price_per_day;
  END IF;

  -- Sync current_odometer ↔ km_driven
  IF NEW.current_odometer IS DISTINCT FROM OLD.current_odometer THEN
    NEW.km_driven := NEW.current_odometer;
  ELSIF NEW.km_driven IS DISTINCT FROM OLD.km_driven THEN
    NEW.current_odometer := NEW.km_driven;
  END IF;

  -- Sync year ↔ model_year
  IF NEW.year IS DISTINCT FROM OLD.year THEN
    NEW.model_year := NEW.year;
  ELSIF NEW.model_year IS DISTINCT FROM OLD.model_year THEN
    NEW.year := NEW.model_year;
  END IF;

  -- Sync image_url ↔ image
  IF NEW.image_url IS DISTINCT FROM OLD.image_url THEN
    NEW.image := NEW.image_url;
  ELSIF NEW.image IS DISTINCT FROM OLD.image THEN
    NEW.image_url := NEW.image;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS sync_vehicle_columns_trigger ON public.vehicles;
CREATE TRIGGER sync_vehicle_columns_trigger
  BEFORE INSERT OR UPDATE ON public.vehicles
  FOR EACH ROW
  EXECUTE FUNCTION sync_vehicle_columns();

-- ============================================================================
-- SYNCHRONIZE EXISTING DATA
-- ============================================================================

UPDATE public.vehicles SET
  vehicle_type = type,
  price_per_day = daily_rate,
  km_driven = current_odometer,
  model_year = year,
  image = image_url
WHERE vehicle_type IS NULL 
   OR price_per_day IS NULL 
   OR km_driven IS NULL 
   OR model_year IS NULL 
   OR image IS NULL;

-- ============================================================================
-- ENSURE INDEXES FOR PERFORMANCE
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_bookings_notes ON public.bookings(notes);
CREATE INDEX IF NOT EXISTS idx_bookings_invoice_number ON public.bookings(invoice_number);
CREATE INDEX IF NOT EXISTS idx_bookings_taken_at ON public.bookings(taken_at);
CREATE INDEX IF NOT EXISTS idx_bookings_returned_at ON public.bookings(returned_at);
CREATE INDEX IF NOT EXISTS idx_bookings_paid_at ON public.bookings(paid_at);
CREATE INDEX IF NOT EXISTS idx_vehicles_category ON public.vehicles(category);
CREATE INDEX IF NOT EXISTS idx_vehicles_segment ON public.vehicles(segment);
CREATE INDEX IF NOT EXISTS idx_customers_notes ON public.customers(notes);

-- ============================================================================
-- MIGRATION COMPLETE
-- ============================================================================
--
-- ALL MISSING COLUMNS ADDED:
-- ✅ vehicles: name, cc, segment, gear_type, category, vehicle_type, price_per_day, km_driven, model_year, image, photos
-- ✅ customers: customer_number, full_name, id_type, id_photos, notes
-- ✅ bookings: notes, booking_number, vehicle_ids, timestamps, financial fields, invoice fields, state tracking
-- ✅ payments: all fields
-- ✅ damages: all fields
-- ✅ documents: all fields
-- ✅ customer_id_photos: side, file_path, damage_repaired_at
-- ✅ vehicle_damage_photos: damage_repaired_at
-- ✅ invoice_sequences: all fields
-- ✅ customer_sequences: all fields
--
-- WHAT NOW WORKS:
-- ✅ Add Vehicle with category, cc, segment, gear_type → SUCCESS
-- ✅ Add Customer with notes → SUCCESS
-- ✅ Create Booking with notes, taken_at, returned_at, paid_at → SUCCESS
-- ✅ Add Payment → SUCCESS
-- ✅ Add Damage → SUCCESS
-- ✅ Soft delete any entity → SUCCESS
-- ✅ No "column not found in schema cache" errors → GUARANTEED
--
-- SAFE CHANGES:
-- ✅ Only added columns
-- ✅ Never dropped data
-- ✅ Never renamed columns without sync triggers
-- ✅ RLS policies untouched
-- ✅ auth.users untouched
-- ✅ All changes idempotent (ADD COLUMN IF NOT EXISTS)
--
-- ============================================================================

COMMIT;
